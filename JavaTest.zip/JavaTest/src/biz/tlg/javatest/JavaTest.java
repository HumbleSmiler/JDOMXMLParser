package biz.tlg.javatest;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.helpers.DateTimeDateFormat;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import biz.tlg.javatest.dto.CardDTO;
import biz.tlg.javatest.dto.CustomerPresent;
import biz.tlg.javatest.dto.TokenDTO;
import biz.tlg.javatest.dto.TransactionDTO;
import biz.tlg.javatest.dto.TransactionType;
import biz.tlg.javatest.messages.Messages;
import biz.tlg.javatest.parser.MessageParser;
import biz.tlg.javatest.utils.Utils;


/**
 * 
 * @author paul.manning
 *
 */
public class JavaTest {
    
    private static final String LOG4J_PROPERTIES = "/log4j.properties";
    
    /** log4j logger */
    private static final Logger LOG = Logger.getLogger(JavaTest.class);
    
    /**
     * USE THIS METHOD....
     */
    private void run() {

        LOG.debug("Starting run method...");

        TransactionDTO transactionDTO = new TransactionDTO();
        
        //write common parsing code to deal with both of theses XML messages into the DTO objects in the DTO package (TransactionDTO sits at the root)
        
	try {
	    MessageParser parser = new MessageParser(Messages.SIMPLE_CARD_MESSAGE_DOC);
	    parser.parseMessage();
	    
	    CardDTO cardDTO;
	    cardDTO = new CardDTO(parser.getPanEle(), parser.getEndAttr());
	    transactionDTO.setCardDTO(cardDTO);
	
	    transactionDTO.setTransactionType(TransactionType.getTransactionType(parser.getTypeAttr()));
	    transactionDTO.setCustomerPresent(CustomerPresent.getCustomerPresent(parser.getCustomerAttr()));
	    transactionDTO.setTransactionAmount(parser.getAmountEle());
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    Date date;
	    // Assuming date to be 2016-09-12
	    date = df.parse("2016-09-12 "+parser.getTimeAttr());
	    transactionDTO.setTransactionTime(date);
	} catch (ParseException | JDOMException e) {
	    LOG.error(e);
	}
        
	TransactionDTO transactionDTO1 = new TransactionDTO();
	
        try {
            MessageParser parser1 = new MessageParser(Messages.COMPLEX_CARD_MESSAGE_DOC);
	    parser1.parseMessage();
	    CardDTO cardDTO;
	    cardDTO = new CardDTO(parser1.getPanEle(), parser1.getEndAttr());
	    cardDTO.setTrack2(parser1.getTrackEle());
	    Collection<TokenDTO> tokenColl = new ArrayList<TokenDTO>();
	    TokenDTO token = new TokenDTO(parser1.getTokenEle(), parser1.getTokenOriginAttr());
	    tokenColl.add(token);
	    cardDTO.setTokens(tokenColl);
	    transactionDTO1.setCardDTO(cardDTO);
	
	    transactionDTO1.setTransactionType(TransactionType.getTransactionType(parser1.getTypeAttr()));
	    transactionDTO1.setCustomerPresent(CustomerPresent.getCustomerPresent(parser1.getCustomerAttr()));
	    transactionDTO1.setTransactionAmount(parser1.getAmountEle());
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    Date date;
	    // Assuming date to be 2016-09-12
	    date = df.parse("2016-09-12 "+parser1.getTimeAttr());
	    transactionDTO1.setTransactionTime(date);
	} catch (ParseException | JDOMException e) {
	    LOG.error(e);
	}

        //Feel free to add new classes & methods as you wish, there are getElement() and getAttribute() methods in the Utils class
        //for you to use. Usage of these methods is demonstrated via unit tests in the UtilsTest class
        
        //Add unit test coverage for some of your code, prioritising areas as you feel appropriate.
        
               
        
        
        
        
        /* Print the content of the DTO objects */
        LOG.info("Output of DTOs...");
        LOG.info(transactionDTO.toString());
        LOG.info(transactionDTO1.toString());

        
    }
    
    /**
     * Run the Java Test
     * 
     * @param args
     */
    public static void main(String[] args) {

        /* Initialise log4j */
        String currentdir = System.getProperty("user.dir");
        System.out.println("Reading log4j properties file: " + LOG4J_PROPERTIES + " ...");
        if (new File(currentdir + LOG4J_PROPERTIES).exists()) {
            PropertyConfigurator.configureAndWatch(currentdir + LOG4J_PROPERTIES);
        } else {
            System.out.println("FAILED - " + currentdir + " Not Found.");
        }
                            
        new JavaTest().run();
        
    }

    
    

}
