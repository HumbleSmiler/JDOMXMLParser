/**
 * 
 */
package biz.tlg.javatest.parser;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.JDOMParseException;

import biz.tlg.javatest.utils.Utils;

/**
 * @author PradeepSingh
 *
 */
public class MessageParser {
    private static final Logger LOG = Logger.getLogger(MessageParser.class);
    private Document message;
    private StringBuilder strB = new StringBuilder();
    private HashMap<String, String> attribList = new HashMap<String, String>();
    
    public MessageParser(Document messageDoc) {
	this.message = messageDoc;
    }

    /**
     * Parse input messages 
     * @throws JDOMException 
     */
    public void parseMessage() throws JDOMException {
	Element el = Utils.getElement(message, "//RLSOLVE_MSG");
	
	if (el == null)
	    throw new IllegalArgumentException();
	    
	traverseDoc(el);
	LOG.debug("Attribute XPath List: "+attribList);
    }
    
    private void traverseDoc(Object current) {
	    if (current instanceof Element) {
		Element element = (Element) current;
		
		strB.append(element.getName());
		strB.append("/");
		
		@SuppressWarnings("rawtypes")
		List lst = element.getAttributes();
		
		if (!lst.isEmpty()) {
		    for (int i=0; i<lst.size();i++) {
			Attribute attr = (Attribute) lst.get(i);
			attribList.put(attr.getName(), strB+"@"+attr.getName().toString());
		    }
		    strB=new StringBuilder("RLSOLVE_MSG/");
		}
		
		@SuppressWarnings("rawtypes")
		List children = element.getContent();
		
		@SuppressWarnings("rawtypes")
		Iterator iterator = children.iterator();
		while (iterator.hasNext()) {
		    Object child = iterator.next();
		    traverseDoc(child);
		}
	    } 
    }
    
    public String getPanEle() throws JDOMException {
	return Utils.getElement(message, "//RLSOLVE_MSG/CARD/PAN").getValue();
    }
    
    public String getTrackEle() throws JDOMException {
	return Utils.getElement(message, "//RLSOLVE_MSG/CARD/TRACK2").getValue();
    }
    
    public String getAmountEle() throws JDOMException {
	return Utils.getElement(message, "//RLSOLVE_MSG/TRANSACTION/AMOUNT").getValue();
    }
    
    public String getEndAttr() throws JDOMException {
	return Utils.getAttribute(message, "//"+attribList.get("end")).getValue();
    }
    
    public String getCustomerAttr() throws JDOMException {
	return Utils.getAttribute(message, "//"+attribList.get("customer")).getValue();
    }
    
    public String getTypeAttr() throws JDOMException {
	return Utils.getAttribute(message, "//"+attribList.get("type")).getValue();
    }
    
    public String getTimeAttr() throws JDOMException {
	return Utils.getAttribute(message, "//"+attribList.get("time")).getValue();
    }

    public String getTokenEle() throws JDOMException {
	return Utils.getElement(message, "//RLSOLVE_MSG/CARD/TOKENS/TOKEN").getValue();
    }

    public String getTokenOriginAttr() throws JDOMException {
	return Utils.getAttribute(message, "//RLSOLVE_MSG/CARD/TOKENS/TOKEN/@origin").getValue();
    }
    
}
