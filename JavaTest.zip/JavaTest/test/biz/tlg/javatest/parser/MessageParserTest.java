package biz.tlg.javatest.parser;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.StringReader;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.junit.Test;

import biz.tlg.javatest.messages.Messages;

/**
 * Some Unit tests for the MessageParser class 
 * 
 */
public class MessageParserTest {
    
    @Test
    public void testParserValidDoc() {
	Document testDoc = Messages.SIMPLE_CARD_MESSAGE_DOC;
	
	final String pan = "4444333322221111";
	final String expiry = "2016-12";
	final String trnType = "refund";
	
	MessageParser parser = new MessageParser(testDoc);
	
	// test
	try {
	    parser.parseMessage();
	    assertEquals("pan is not expected value: "+pan+", is: " + 
	    	parser.getPanEle(), pan, parser.getPanEle());

	    assertEquals("card expiry is not expected value: "+expiry+", is: " + 
		    	parser.getEndAttr(), expiry, parser.getEndAttr());
	    
	    assertEquals("transactionType is not expected value: "+trnType+", is: " + 
		    	parser.getTypeAttr(), trnType, parser.getTypeAttr());
	    // ... repeat
	    
	} catch (JDOMException e) {
	    fail();
	}
	
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testParserInValidDoc() throws JDOMException, IOException {
	final String testStr = "<SOLVE_MSG></SOLVE_MSG>";
	
	Document testDoc = new SAXBuilder().build(new StringReader(testStr));
	MessageParser parser = new MessageParser(testDoc);
	parser.parseMessage();
    }
}
